import UIKit
import RxSwift

let dispose = DisposeBag()

print("publish")
let publishSubject = PublishSubject<String>()

publishSubject.onNext("여러분 안녕하세요?")

let g = publishSubject
    .subscribe(onNext: {
        print($0)
    })
    .disposed(by: dispose)

publishSubject.onNext("들리세요?")
publishSubject.on(.next("안들리시나요?"))

let gg = publishSubject
    .subscribe(onNext: {
        print($0)
    })
    .disposed(by: dispose)

publishSubject.onNext("4. 여보세요")
publishSubject.onCompleted()

publishSubject.onNext("5. 끝났나요")
