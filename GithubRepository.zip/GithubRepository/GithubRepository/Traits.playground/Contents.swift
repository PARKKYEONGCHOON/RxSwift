import UIKit
import RxSwift

let disposeBag = DisposeBag()

enum TraitsError: Error {
    case Single
    case maybe
    case completable
}

print("Single")

Single<String>.just("d")
    .subscribe(
        onSuccess: {
            print($0)
        },
        onFailure: {_ in
            print("Error")
        },
        onDisposed: {
            print("disposed")
        }
    )
