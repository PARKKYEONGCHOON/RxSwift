import RxSwift

let disposeBag = DisposeBag()

print("--ignoreElements--")

let mode = PublishSubject<String>()

mode
    .ignoreElements()
    .subscribe {
        print($0)
    }
    .disposed(by: disposeBag)

mode.onNext("dasdad")
mode.onNext("dasdad")
mode.onNext("dasdad")

mode.onCompleted()

print("----elementAt----")
let ss = PublishSubject<String>()

ss
    //.element(at: 2)
    .subscribe(onNext: {
        print($0)
    })
    .disposed(by: disposeBag)

ss.onNext("Dasds")
ss.onNext("Dasds")
ss.onNext("Dasds")
ss.onNext("Dasds")

